#!/bin/bash

curl -sS "https://raw.githubusercontent.com/wayangkulit95/siakap/momok/menu/dashboard.sh" | bash
